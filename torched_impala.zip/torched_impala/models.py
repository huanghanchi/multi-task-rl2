import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions.categorical import Categorical
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
dtype = torch.double


class MlpPolicy(nn.Module):
    def __init__(self, obs_dim: int, action_dim: int, hidden_dim: int):
        super(MlpPolicy, self).__init__()
        self.image_conv = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=16, kernel_size=(2, 2)),
            nn.ReLU(),
            nn.AvgPool2d(kernel_size=(2, 2), stride=2),
            nn.Conv2d(in_channels=16, out_channels=32, kernel_size=(2, 2)),
            nn.ReLU(),
            nn.Conv2d(in_channels=32, out_channels=16, kernel_size=(2, 2)),
            nn.ReLU(),
        )

        # Define actor's model
        
        self.model = (
            nn.Sequential(
                nn.Linear(16, 64),
                nn.ReLU(),
                nn.Linear(64, action_dim),
            )
            .to(device)
            .to(dtype)
        )

    def forward(self, x) :
        
        x = x.image.transpose(1, 3).transpose(2, 3).float().to(device)
        x = self.image_conv(x)
        x = x.reshape(x.shape[0], -1)
        
        embedding = x.double()
        x = self.model(embedding)
        return x

    def select_action(self, obs: torch.Tensor, deterministic: bool = False):
        logits = self.forward(obs)
        if deterministic:
            action = torch.argmax(logits)
        else:
            action = torch.multinomial(F.softmax(logits, dim=-1), num_samples=1)

        return action, logits


class MlpValueFn(nn.Module):
    def __init__(self, obs_dim: int, hidden_dim: int):
        super(MlpValueFn, self).__init__()
        self.image_conv = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=16, kernel_size=(2, 2)),
            nn.ReLU(),
            nn.AvgPool2d(kernel_size=(2, 2), stride=2),
            nn.Conv2d(in_channels=16, out_channels=32, kernel_size=(2, 2)),
            nn.ReLU(),
            nn.Conv2d(in_channels=32, out_channels=16, kernel_size=(2, 2)),
            nn.ReLU(),
        )

        # Define actor's model
        
        self.model = (
            nn.Sequential(
                nn.Linear(16, 64),
                nn.ReLU(),
                nn.Linear(64, 1),
            )
            .to(device)
            .to(dtype)
        )


    def forward(self, observation):
        x = observation.transpose(1, 3).transpose(2, 3).to(device).double()
        x = self.image_conv(x)
        x = x.reshape(x.shape[0], -1)
        
        embedding = x.double()
        
        x = self.model(embedding)
        value = x.squeeze(1)
        return self.model(observation)
